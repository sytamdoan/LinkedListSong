#include "LinkedList.h"
#include "Song.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
/*
The default constructor for linkedlist. Creating a NULL.
*/
LinkedList::LinkedList() {
  first = NULL;
}
/*
This function checks if the list is empty. If there is no first element, then it is empty
@return returns true if it is empty, return false otherwise.
*/
bool LinkedList::isEmpty() {
  if (first == NULL) {
    return true;
  } else {
    return false;
  }
}
/*
This function takes in a song object and adds it into the to the linkedlist at the end.
@param takes in a song to be added to the list
*/
void LinkedList::add(Song s){
  Node *newNode = new Node;
  newNode -> data = s;
  newNode -> next = NULL;
  if ( first == NULL) {
    first = newNode;
  } else {
    Node *n = first;
    while (n -> next != NULL) {
      n = n -> next;
    }
    n -> next = newNode;
  }
}
/*
This function takes in the list and returns the size of the list
@return returns the size of the list
*/
int LinkedList::size() {
  Node *n = first;
  int count = 0;
  while ( n != NULL) {
    n = n -> next;
    count++;
  }
  return count;
}
/*
removes the first element of the list and returns its data
@return returns the information regarding the song being removed
*/
Song LinkedList::remove() {
  Song returnSong;
  if(first != NULL) {
    returnSong = first-> data;
    Node *tempNode = first -> next;
    delete first;
    first = tempNode;
  }

  return returnSong;
}
/*
This funtion searches a song in the list using the given song name and given artist name.
@param song takes in the name of the song being searched
@param artist takes in the name of the artist being searched
@return returns the data of the song being found, or if nothing is found, then returns an empty song with empty data
*/
Song LinkedList::searchSong(string Title, string Artist) {
  Node *n = first;
  Song songA;
  while (n != NULL) {
    if(n->data.getTitle() == Title && n->data.getArtist() == Artist) {
      return n->data;
    }
    n = n->next;
  }
  cout << "Song Not Found" << endl;
  return songA;
}
/*
This function search for an artist returns the list of song from the artist in a vector.
@param artist searches the list for the artist
@return songList returns a list of songs from the selected artist
*/
vector<Song> LinkedList::searchArtist(string artist) {
  vector<Song> songList;
  Node *n = first;
  while (n != NULL) {
    if(n -> data.getArtist() == artist) {
      songList.push_back(n->data);
    }
    n = n->next;
  }
  return songList;
}

/*
returns a list of song from a certain decade in a vector. The parameter will only take in numbers in decades
@param decade takes in an integer to be examined which song is made in that decade
@return returns the list of song made in the decade
*/
vector<Song> LinkedList::searchDecade(int decade) {
  vector<Song> decadeList;
  Node *n = first;
  int lowend = decade;
  int highend = decade + 9;
  while (n != NULL) {
    if(n -> data.getYear() >= lowend && n -> data.getYear() <= highend) {
      decadeList.push_back(n->data);
    }
    n = n -> next;
  }
  return decadeList;
}
/*
sorts out the list of songs in terms of ratings in a bubble sort manner.
*/
void LinkedList::sort() {
  bool swapped = false;
  do {
    Node *n = first;
    swapped = false;
    while(n->next != NULL) {
      if (n->next-> data.getRating() > n->data.getRating()) {
        Song swap = n->data;
        n->data = n->next->data;
        n->next->data = swap;
        swapped = true;
      }
      n = n->next;
    }
  } while(swapped);
}
/*
This function displays all the information relating to an element in a list, such as title, artist, year, rating.
@param list takes in the list to be displayed out
@return out returns what is being outputted
*/
ostream &operator<<(ostream &out, LinkedList list){
  LinkedList::Node *n;
  n=list.first;
  while (n != NULL) {
    out << n->data.getTitle() << ',' <<n->data.getArtist() << ',' << n->data.getYear() << ',';
    out << n->data.getRating();
    n = n -> next;
  }
  return out;
}