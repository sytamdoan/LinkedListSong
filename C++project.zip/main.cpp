#include <string>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <fstream>
#include "CheckInput.h"
#include "LinkedList.h"
#include "Song.h"
using namespace std;
/*
Author: Tam Doan
This function plays with a linkedlist and fills it with songs from songs.txt. The elements in the list can then be manipulated and change with add, play search, etc.
*/
/*
The first function, add, adds in a song to to the list.
@param list takes in the list to be added to be added to
*/
void add(LinkedList &list){
  Song s1;
  cin >> s1;
  list.add(s1);
}
/*
The play function plays the first song of the list and displays its title, artist, year, rating.
@param list takes in the list to be played and removed
*/
LinkedList play(LinkedList list){
  list.sort();
  Song s = list.remove();
  cout << s << endl;
  return list;
}
/*
The search function gives the user 3 options to search the list. The user can search in terms of title and artist, artist, decade, or they can quit.
@param list takes in the list to be searched
*/
void search(LinkedList list) {
  cout << "What would you like to search?" << endl;
  cout << "1. Title and Artist"<< endl;
  cout << "2. Artist"<< endl;
  cout << "3. Decade"<< endl;
  cout << "4. quit"<< endl;
  int choice = 0;

  while (choice != 4) {
    choice = getIntRange(1,4);
    if (choice == 1){
      string artists;
      string titles;
      cin.ignore();
      cout << "Which title?" << endl;
      getline(cin,titles);
      cin.clear();
      cout << "Which artist?" << endl;
      getline(cin,artists);
      cin.clear();
      Song song = list.searchSong(titles,artists);
      if( song.getYear() == 0) {
        cout << "Song not found" << endl; 
      } else {
        cout << song.getTitle() << endl;
        cout << song.getArtist() << endl;
        cout << song.getYear() << endl;
        cout << song.getRating() << endl;
      }

      cout << "What would you like to search?" << endl;
    } else if (choice == 2) {
      string artists;
      cout << "Which artist?" << endl;
      cin.ignore();
      getline(cin,artists);
      cin.clear();
      vector<Song> songList = list.searchArtist(artists);
      if (songList.size() == 0) {
        cout << "Artist not found" << endl;
      } else {
        for (int i = 0; i < songList.size(); i++) {
          cout << songList[i] << endl;
        }
      }

      cout << "What would you like to search?" << endl;
    } else if (choice == 3) {
      int decade = 0;
      cout << "Which decade?" << endl;
      cin >> decade;
      while(decade % 10 != 0) {
        cout << "Please enter a decade" << endl;
        cin >> decade;
      }
      vector<Song> songList = list.searchDecade(decade);
      if (songList.size() == 0) {
        cout << "No song from this decade" << endl;
      } else {
        for (int i = 0; i < songList.size(); i++) {
          cout << songList[i] << endl;
        }
      }
      cout << "What would you like to search?" << endl;

    } else {
      cout << "No more searches"<< endl;
    }
  }
}
/*
displays the rest whole linked list when already sorted
@param takes in the list to be displayed
*/
void display(LinkedList list){
  cout << list << endl;
}

int main() {
  fstream file;
  int options = 0;
  int count = 1;
  string a, b, c, d;
  string input;
  LinkedList list;
  file.open("songs.txt", ios::in);
  if( file ) {
    while(getline(file,input,',')) {
      if (count == 1){
        a = input;
        count++;
      } else if (count == 2){
        b = input;
        count++;
      } else if (count == 3){
        c = input;
        file>>d;
        getline(file,input,'\n');
        Song examples(a,b,c,d);
        list.add(examples);
        count = 1;
      }
    }
    file.close();
  } else {
    cout << "Could not open file.";
  }

  while (options != 5) {
    cout << "What would you like to do?" << endl;
    cout << "1. Add" << endl;
    cout << "2. Play" << endl;
    cout << "3. Search" << endl;
    cout << "4. display" << endl;
    cout << "5. Quit" << endl;
    options = getIntRange(1,5);
    if (options == 1) {
      add(list);
      list.sort();
    } else if (options == 2) {
      list = play(list);
    } else if (options == 3) {
      search(list);
    } else if (options == 4) {
      list.sort();
      display(list);
    } else if (options == 5) {
      cout << "Okay, good bye.";
      file.open("songs.txt", ios::out);
      if (file) {
        file << list;
        file.close();
      } else {
        cout << "file not opened" << endl;
      }
    }
  }
}