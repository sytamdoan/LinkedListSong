#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <iostream>
#include <vector>
#include <string>
#include "Song.h"
using namespace std;

/*
This is the header file for the LinkedList file, containing all methods and construtors for LinkedList.
*/
class LinkedList {
  private:
    struct Node {
      Song data;
      Node *next;
    };
    Node *first;

  public:
    LinkedList();
    bool isEmpty();
    void add(Song s);
    int size();
    Song remove();
    Song searchSong(string Title, string Artist);
    vector<Song> searchArtist(string artist);
    vector<Song> searchDecade(int decade);
    void sort();
    friend ostream &operator<<(ostream &out, LinkedList list);  
};
#endif