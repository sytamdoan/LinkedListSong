#include "Song.h"
#include <string>
#include <iostream>
/*
The default constructor for song
*/
Song::Song()  {
  title = "";
  artist = "";
  year = 0;
  rating = 0;
}

Song::Song(string x, string y,string a, string b) {
  title = x;
  artist = y;

  int years = stoi(a);
  int ratings = stoi(b);

  year = years;
  rating = ratings;
}
/*
The first overload constructor takes in 2 parameter, the title and artist. This then takes in the parameters and implement it at title and artist.
@param x passes in a string to be used as title
@param y passes in a string to be used as artist
*/
Song::Song(string x, string y){

  title = x;
  artist = y;

}
/*
The first overload constructor takes in 4 parameter, the title and artist, and the year and rating. This then takes in the parameters and implement it at title,artist,year, and rating respectively.
@param x passes in a string to be used as title
@param y passes in a string to be used as artist
@param a passes in an integer to be used as year
@param b passes in an integer to be used as rating
*/
Song::Song(string x, string y, int a, int b){
  title = x;
  artist = y;
  year = a;
  rating = b;
}
/*
returns the title of the song
@return returns title
*/
string Song::getTitle(){
  return title;
}
/*
returns the artist of the song
@return returns artist
*/
string Song::getArtist(){
  return artist;
}
/*
returns the year of the song
@return returns year
*/
int Song::getYear(){
  return year;
}
/*
returns the rating of the song
@return returns rating
*/
int Song::getRating(){
  return rating;
}
/*
this is the overloaded operator for << for Song. Displays everything about the song object.
@return out returns the output
*/
ostream &operator<<(ostream &out, Song &b){
  out << b.title << ',' << b.artist << ',' << b.year << ',' << b.rating << endl;
  return out;
}
/*
The overloaded operator for >>. This uses to enter title, artist, year, and rating into the object of song.
*/
istream &operator>>(istream &in, Song &b){
  string title;
  string artist;
  int year;
  int rating;

  cout << "Enter title :" << endl;
  in >> title;
  cout << "Enter Artist :" << endl;
  in >> artist;
  cout << "Enter year :" << endl;
  in >> year;
  cout << "Enter rating :" << endl;
  in >> rating;

  b.title = title;
  b.artist = artist;
  b.year = year;
  b.rating = rating;
  return in;
}
/*
the == overloaded operator.compares the two songs and returns true if title and artist are the same. returns false if either of them are not
@param song is used to be compared to with another song
@return returns true or false depending on if title and artist are the same
*/
bool Song::operator== (Song b){
  if(this -> title == b.title && this -> artist == this -> artist) {
    return true;
  } else {
    return false;
  }
}
/*
this is the overload operator for > for song. It first compares the ratings, if one rating is higher than another, then it would return true, if the rating is less, then false is returned. If ratings are the same, then artist are compared, then to title.
@return true or false depending on rating, artist, and title;
*/
bool Song::operator> (Song b){
  if(this -> rating > b.rating) {
    return true;
  } else if (this -> rating < b.rating){
    return false;
  } else {
    if (this -> artist > b.artist) {
      return true;
    } else if (this -> artist < b.artist) {
      return false;
    } else {
      if (this -> title > b.title) {
        return true;
      }else if (this -> title < b.title) {
      return false;
      } else {
      return false;
      }
    }
  }
}