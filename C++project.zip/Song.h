#ifndef SONG_H
#define SONG_H
#include <string>
#include <iostream>
using namespace std;
/*
This is the object class Song.
@instant variable a title contains the string title of song
@instant variable a artist contains the string artist of song
@instant variable a year contains the int year of song
@instant variable a rating contains the int rating of song
*/
class Song {
  private:
    string title;
    string artist;
    int year;
    int rating;

  public:
    Song();
    Song(string x, string y);
    Song(string x, string y, string a, string b);
    Song(string x, string y, int a, int b);
    string getTitle();
    string getArtist();
    int getYear();
    int getRating();

    friend ostream &operator<<(ostream &out, Song &b);
    friend istream &operator>>(istream &in, Song &b);
    bool operator== (Song b);
    bool operator> (Song b);
};
#endif